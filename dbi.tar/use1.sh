cp 1test.cc test.cc
cp 1test.h test.h
