cp 3test.cc test.cc
cp 3test.h test.h
